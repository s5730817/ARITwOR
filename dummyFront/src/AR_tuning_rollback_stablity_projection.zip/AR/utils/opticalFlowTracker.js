import { extractCameraFeatures } from "./cameraFeatures";
// tunables
const MAX_POINTS = 25;
const MIN_POINTS = 8;
const maxErr = 20;
const maxMotion = 80;


let trackingState = {
  active: false,
  prevGray: null,
  cameraPoints: [],
  mapPoints: [],
  synthetic: [],
  weakFrames: 0,
  age: 0
};

// -----------------------------
// Reset
// -----------------------------
export function resetOpticalFlowState() {
  if (trackingState.prevGray) {
    trackingState.prevGray.delete();
  }

  trackingState = {
    active: false,
    prevGray: null,
    cameraPoints: [],
    mapPoints: [],
    synthetic: [],
    weakFrames: 0,
    age: 0
  };
}

// -----------------------------
// Active check
// -----------------------------
export function hasActiveTracking() {
  return (
    trackingState.active &&
    trackingState.prevGray &&
    trackingState.cameraPoints.length >= 4 &&
    trackingState.mapPoints.length === trackingState.cameraPoints.length
  );
}

// -----------------------------
// Init from inliers
// -----------------------------
export function initializeTrackingFromInliers(frame, inlierMatches) {
  const cv = window.cv;
  if (!cv) return false;
  if (!frame || !inlierMatches || inlierMatches.length < 6) return false;

  const gray = toGrayMat(frame);
  if (!gray) return false;

  if (trackingState.prevGray) {
    trackingState.prevGray.delete();
  }

  trackingState.prevGray = gray;

  
  const selected = inlierMatches.slice(0, MAX_POINTS);

  trackingState.cameraPoints = selected.map(m => ({
    x: m.cam?.x ?? m.camera?.x,
    y: m.cam?.y ?? m.camera?.y
  }));

  trackingState.mapPoints = selected.map(m => ({
    x: m.map.x,
    y: m.map.y
  }));

  trackingState.synthetic = selected.map(() => false);

  trackingState.active = true;
  trackingState.weakFrames = 0;
  trackingState.age = 0;

  return true;
}

// -----------------------------
// Optical Flow Tracking
// -----------------------------
export function trackPointsWithOpticalFlow(frame) {
  const cv = window.cv;

  if (!cv || !hasActiveTracking() || !frame) {
    return {
      ok: false,
      reason: "tracking inactive",
      trackedMatches: []
    };
  }

  const nextGray = toGrayMat(frame);
  if (!nextGray) {
    return {
      ok: false,
      reason: "failed to build gray frame",
      trackedMatches: []
    };
  }

  const prevPtsArray = [];
  for (const p of trackingState.cameraPoints) {
    prevPtsArray.push(p.x, p.y);
  }

  const prevPts = cv.matFromArray(
    trackingState.cameraPoints.length,
    1,
    cv.CV_32FC2,
    prevPtsArray
  );

  const nextPts = new cv.Mat();
  const status = new cv.Mat();
  const err = new cv.Mat();

  cv.calcOpticalFlowPyrLK(
    trackingState.prevGray,
    nextGray,
    prevPts,
    nextPts,
    status,
    err,
    new cv.Size(21, 21),
    3,
    new cv.TermCriteria(
      cv.TERM_CRITERIA_EPS | cv.TERM_CRITERIA_COUNT,
      30,
      0.01
    )
  );

  const trackedMatches = [];

  

  for (let i = 0; i < trackingState.cameraPoints.length; i++) {
    if (status.data[i] !== 1) continue;

    const prev = trackingState.cameraPoints[i];

    const x = nextPts.data32F[i * 2];
    const y = nextPts.data32F[i * 2 + 1];
    const e = err.data32F ? err.data32F[i] : 0;

    if (!Number.isFinite(x) || !Number.isFinite(y)) continue;
    if (x < 0 || y < 0 || x >= nextGray.cols || y >= nextGray.rows) continue;
    if (Number.isFinite(e) && e > maxErr) continue;

    const dx = x - prev.x;
    const dy = y - prev.y;
    if (dx * dx + dy * dy > maxMotion * maxMotion) continue;

    trackedMatches.push({
      map: trackingState.mapPoints[i],
      camera: { x, y },
      synthetic: trackingState.synthetic[i] || false
    });
  }

  prevPts.delete();
  nextPts.delete();
  status.delete();
  err.delete();

  if (trackingState.prevGray) {
    trackingState.prevGray.delete();
  }
  trackingState.prevGray = nextGray;

  // -----------------------------
  // NON-DESTRUCTIVE UPDATE
  // -----------------------------
  if (trackedMatches.length >= 4) {
    trackingState.cameraPoints = trackedMatches.map(m => m.camera);
    trackingState.mapPoints = trackedMatches.map(m => m.map);
    trackingState.synthetic = trackedMatches.map(m => m.synthetic || false);

    if (trackedMatches.length >= 8) {
      trackingState.weakFrames = 0;
    } else {
      trackingState.weakFrames += 1;
    }

  } else {
    trackingState.weakFrames += 1;
  }

  trackingState.age += 1;

  // -----------------------------
  // 🌱 RESEEDING (RESTORED)
  // -----------------------------
 

  if (
    trackingState.cameraPoints.length < MIN_POINTS &&
    trackingState.weakFrames > 2
  ) {
    const newFeatures = extractCameraFeatures(frame);

    if (newFeatures && newFeatures.length > 0) {
      const needed = MAX_POINTS - trackingState.cameraPoints.length;
      const toAdd = [];

      for (const f of newFeatures) {
        if (toAdd.length >= needed) break;

        let tooClose = false;

        for (const existing of trackingState.cameraPoints) {
          const dx = existing.x - f.x;
          const dy = existing.y - f.y;

          if (dx * dx + dy * dy < 25 * 25) {
            tooClose = true;
            break;
          }
        }

        if (!tooClose) {
          toAdd.push(f);
        }
      }

      for (const f of toAdd) {
        trackingState.cameraPoints.push({ x: f.x, y: f.y });
        trackingState.mapPoints.push({ x: f.x, y: f.y });
        trackingState.synthetic.push(true);
      }

      trackingState.cameraPoints = trackingState.cameraPoints.slice(0, MAX_POINTS);
      trackingState.mapPoints = trackingState.mapPoints.slice(0, MAX_POINTS);
      trackingState.synthetic = trackingState.synthetic.slice(0, MAX_POINTS);

      if (toAdd.length > 0) {
        console.log("🌱 Reseeded:", toAdd.length);
      }
    }
  }

  // -----------------------------
  // ONLY return real matches for homography
  // -----------------------------
  const realMatches = trackedMatches.filter(m => !m.synthetic);

  return {
    ok: realMatches.length >= 4,
    weak: realMatches.length < 8,
    confidence: realMatches.length,
    reason:
      realMatches.length < 4
        ? "very low tracked points"
        : realMatches.length < 8
        ? "weak tracking"
        : null,
    trackedMatches: realMatches
  };
}

// -----------------------------
export function refreshTrackingFromInliers(frame, inlierMatches) {
  return initializeTrackingFromInliers(frame, inlierMatches);
}

// -----------------------------
function toGrayMat(frame) {
  const cv = window.cv;
  if (!cv || !frame) return null;

  let mat;
  try {
    mat = cv.matFromImageData(frame);
  } catch {
    return null;
  }

  if (!mat || mat.rows === 0 || mat.cols === 0) {
    return null;
  }

  const gray = new cv.Mat();
  cv.cvtColor(mat, gray, cv.COLOR_RGBA2GRAY);

  mat.delete();
  return gray;
}